import React, { useState } from 'react';
import { useTour } from '../../context/TourContext';
import { TourPackage } from '../../types/tour';
import { 
  Calendar, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  X,
  Compass,
  AlertTriangle,
  DollarSign,
  CreditCard,
  Building,
  ArrowLeftRight,
  Globe
} from 'lucide-react';

export const PackagesSection: React.FC = () => {
  const { packages, openInquireForPackage, selectedCurrency, setSelectedCurrency } = useTour();
  const [inspectingPackage, setInspectingPackage] = useState<TourPackage | null>(null);

  // Normalize to either USD or IDR for this toggle
  const currentCurrency = selectedCurrency === 'IDR' ? 'IDR' : 'USD';

  const formatPrice = (pkg: TourPackage) => {
    if (currentCurrency === 'IDR') {
      const idrPrice = pkg.indicativePriceIdr || 9200000;
      const usdEquivalent = pkg.indicativePriceUsd || Math.round(idrPrice / 16000);
      return {
        formatted: `Rp ${idrPrice.toLocaleString('id-ID')}`,
        currencyCode: 'IDR',
        perPaxLabel: '/ orang (tur privat)',
        equivalentText: `≈ $${usdEquivalent.toLocaleString()} USD`,
        depositText: `Deposit 30%: Rp ${Math.round(idrPrice * 0.3).toLocaleString('id-ID')}`
      };
    } else {
      const usdPrice = pkg.indicativePriceUsd || 575;
      const idrEquivalent = pkg.indicativePriceIdr || usdPrice * 16000;
      return {
        formatted: `$${usdPrice.toLocaleString()} USD`,
        currencyCode: 'USD',
        perPaxLabel: '/ guest (private tour)',
        equivalentText: `≈ Rp ${idrEquivalent.toLocaleString('id-ID')}`,
        depositText: `30% Deposit: $${Math.round(usdPrice * 0.3).toLocaleString()} USD`
      };
    }
  };

  return (
    <section id="packages" className="py-24 bg-white text-slate-800 px-4 sm:px-6 lg:px-8 border-b border-stone-200">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Section Header with Currency Toggle */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto space-y-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
            <Compass className="w-3.5 h-3.5 text-emerald-700" />
            <span>Curated Expedition Catalog</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-['Playfair_Display'] text-slate-900">
            Private Expeditions & Custom Overland Routes
          </h2>

          <p className="text-stone-600 text-sm leading-relaxed">
            Every journey is operated strictly as a private expedition. Explore our starting rates below or request a tailored quotation customized to your exact party size and travel window.
          </p>

          {/* Interactive Currency Switcher */}
          <div className="pt-3 flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-500">
              <Globe className="w-3.5 h-3.5 text-emerald-700" />
              <span>Currency Preference / Preferensi Mata Uang</span>
            </div>
            
            <div className="inline-flex items-center p-1.5 bg-stone-100/90 rounded-2xl border border-stone-200/90 shadow-xs">
              <button
                type="button"
                onClick={() => setSelectedCurrency('USD')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  currentCurrency === 'USD'
                    ? 'bg-[#0F2922] text-white shadow-sm ring-1 ring-emerald-600/30'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
                }`}
                aria-label="Switch pricing to USD"
              >
                <span className="text-sm">🇺🇸</span>
                <span>USD ($)</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                  currentCurrency === 'USD' ? 'bg-white/20 text-emerald-200' : 'bg-stone-200 text-stone-600'
                }`}>
                  International
                </span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedCurrency('IDR')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  currentCurrency === 'IDR'
                    ? 'bg-[#0F2922] text-white shadow-sm ring-1 ring-emerald-600/30'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
                }`}
                aria-label="Switch pricing to IDR"
              >
                <span className="text-sm">🇮🇩</span>
                <span>IDR (Rp)</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                  currentCurrency === 'IDR' ? 'bg-white/20 text-emerald-200' : 'bg-stone-200 text-stone-600'
                }`}>
                  Indonesia
                </span>
              </button>
            </div>

            {/* Exchange Benchmark Note */}
            <div className="inline-flex items-center gap-2 text-[11px] text-stone-500 bg-stone-50 px-3 py-1 rounded-full border border-stone-200">
              <ArrowLeftRight className="w-3 h-3 text-emerald-700" />
              <span>Benchmark rate: <strong>1 USD ≈ 16,000 IDR</strong> • Guaranteed fixed quotation upon reservation</span>
            </div>
          </div>
        </div>

        {/* Packages Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {packages.filter(p => p.active).map((pkg) => {
            const price = formatPrice(pkg);

            return (
              <div
                key={pkg.id}
                className="rounded-3xl bg-[#FAF9F6] border border-stone-200 overflow-hidden hover:shadow-xl hover:border-emerald-700/40 transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Cover Image */}
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={pkg.coverImage}
                      alt={pkg.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />

                    {/* Top badges */}
                    <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0F2922] text-white shadow-sm">
                        {pkg.indicativeDuration}
                      </span>
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/90 text-slate-800 border border-stone-200 backdrop-blur-md capitalize">
                        {pkg.serviceTier.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="absolute bottom-4 left-6 right-6">
                      <div className="flex items-center gap-1.5 text-xs text-emerald-200 font-medium">
                        <MapPin className="w-3.5 h-3.5 text-emerald-300" />
                        <span>{pkg.destinationName}</span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-bold font-['Playfair_Display'] text-white mt-1">
                        {pkg.title}
                      </h3>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 space-y-4">
                    <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                      {pkg.shortDescription}
                    </p>

                    {/* Highlights */}
                    <div className="space-y-2 pt-2 border-t border-stone-200/60">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400">
                        Key Journey Highlights
                      </span>
                      {pkg.highlights.slice(0, 3).map((h, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-stone-700">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                          <span>{h}</span>
                        </div>
                      ))}
                    </div>

                    {/* Interactive Price Card Display */}
                    <div className="p-4 rounded-2xl bg-white border border-stone-200/90 shadow-xs space-y-2">
                      <div className="flex items-baseline justify-between flex-wrap gap-2">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
                            Indicative Private Expedition Rate
                          </span>
                          <div className="flex items-baseline gap-1.5 mt-0.5">
                            <span className="text-2xl font-extrabold font-mono text-emerald-950">
                              {price.formatted}
                            </span>
                            <span className="text-xs text-stone-500 font-normal">
                              {price.perPaxLabel}
                            </span>
                          </div>
                        </div>

                        {/* Conversion & Currency Tag */}
                        <div className="text-right">
                          <span className="text-[11px] font-mono text-stone-500 block">
                            {price.equivalentText}
                          </span>
                          <span className="text-[10px] text-emerald-800 font-medium font-mono">
                            {price.depositText}
                          </span>
                        </div>
                      </div>

                      <div className="text-[11px] text-stone-500 pt-1.5 border-t border-stone-100 flex items-center justify-between flex-wrap gap-2">
                        <span className="text-[11px]">Includes private luxury chauffeur & certified guides</span>
                        <button
                          type="button"
                          onClick={() => setSelectedCurrency(currentCurrency === 'USD' ? 'IDR' : 'USD')}
                          className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100/90 px-2.5 py-1 rounded-lg border border-emerald-200 transition-all cursor-pointer shadow-2xs"
                        >
                          <ArrowLeftRight className="w-3 h-3 text-emerald-700" />
                          <span>Switch to {currentCurrency === 'USD' ? '🇮🇩 IDR (Rp)' : '🇺🇸 USD ($)'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="p-6 pt-0 flex flex-col sm:flex-row items-center gap-3">
                  <button
                    onClick={() => setInspectingPackage(pkg)}
                    className="w-full sm:w-1/2 py-2.5 px-4 rounded-xl bg-white hover:bg-stone-100 text-stone-800 border border-stone-200 text-xs font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    <Clock className="w-3.5 h-3.5 text-emerald-800" />
                    <span>View Itinerary Details</span>
                  </button>

                  <button
                    onClick={() => openInquireForPackage(pkg.id)}
                    className="w-full sm:w-1/2 py-2.5 px-4 rounded-xl bg-[#0F2922] hover:bg-[#153A30] text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Request Custom Quote</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Package Itinerary & Inclusions Modal */}
      {inspectingPackage && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white border border-stone-200 rounded-3xl w-full max-w-3xl text-stone-800 shadow-2xl relative overflow-hidden my-auto max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="px-6 py-5 border-b border-stone-200 flex items-center justify-between bg-[#FAF9F6] shrink-0">
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-emerald-800">
                  {inspectingPackage.indicativeDuration} • {inspectingPackage.tourType.replace('_', ' ')}
                </span>
                <h3 className="text-xl sm:text-2xl font-bold font-['Playfair_Display'] text-slate-900">
                  {inspectingPackage.title}
                </h3>
              </div>
              <button
                onClick={() => setInspectingPackage(null)}
                className="p-2 rounded-xl text-stone-500 hover:text-stone-900 hover:bg-stone-200/60"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable details */}
            <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm">
              {/* Pricing Overview in Modal with Currency Switcher */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
                    Expedition Pricing ({currentCurrency})
                  </span>
                  <div className="text-2xl font-extrabold font-mono text-emerald-950 mt-0.5">
                    {formatPrice(inspectingPackage).formatted}
                    <span className="text-xs font-normal text-stone-600 ml-1.5 font-sans">
                      {formatPrice(inspectingPackage).perPaxLabel}
                    </span>
                  </div>
                  <span className="text-xs text-stone-500 block mt-0.5">
                    {formatPrice(inspectingPackage).depositText} • {formatPrice(inspectingPackage).equivalentText}
                  </span>
                </div>

                <div className="inline-flex p-1 bg-white rounded-xl border border-stone-200 shadow-xs shrink-0 self-start sm:self-center">
                  <button
                    type="button"
                    onClick={() => setSelectedCurrency('USD')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      currentCurrency === 'USD'
                        ? 'bg-[#0F2922] text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                    }`}
                  >
                    <span>🇺🇸</span>
                    <span>USD ($)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedCurrency('IDR')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      currentCurrency === 'IDR'
                        ? 'bg-[#0F2922] text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                    }`}
                  >
                    <span>🇮🇩</span>
                    <span>IDR (Rp)</span>
                  </button>
                </div>
              </div>

              {/* Experience Narrative */}
              <div>
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-2">
                  The Experience Narrative
                </h4>
                <p className="text-stone-700 leading-relaxed text-xs">
                  {inspectingPackage.experienceNarrative}
                </p>
              </div>

              {/* Day by Day Plan */}
              <div>
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-3">
                  Day-by-Day Program Schedule
                </h4>
                <div className="space-y-3">
                  {inspectingPackage.itineraryDays.map((day) => (
                    <div key={day.dayNumber} className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-900 text-xs">
                          Day {day.dayNumber}: {day.title}
                        </span>
                        <span className="text-[11px] text-stone-500 font-medium">
                          Stay: {day.stayLocation}
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 italic">{day.subtitle}</p>

                      <div className="space-y-1.5 pt-2 border-t border-stone-200">
                        {day.schedule.map((sc, scIdx) => (
                          <div key={scIdx} className="flex items-start gap-2 text-xs">
                            <span className="font-mono text-emerald-800 shrink-0 text-[11px] font-bold">{sc.time}</span>
                            <span className="text-stone-700 text-[11px]">{sc.activity} ({sc.location})</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Inclusions and Exclusions Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                  <h5 className="font-bold text-emerald-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                    <span>Included Services</span>
                  </h5>
                  <ul className="space-y-1.5 text-xs text-stone-700">
                    {inspectingPackage.inclusions.map((inc, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-emerald-700 mt-0.5">•</span>
                        <span className="text-[11px]">{inc}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                  <h5 className="font-bold text-stone-700 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <XCircle className="w-4 h-4 text-stone-500" />
                    <span>Excluded from Package</span>
                  </h5>
                  <ul className="space-y-1.5 text-xs text-stone-600">
                    {inspectingPackage.exclusions.map((exc, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-stone-400 mt-0.5">•</span>
                        <span className="text-[11px]">{exc}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Safety Mandates */}
              {inspectingPackage.safetyMandates.length > 0 && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs space-y-2">
                  <div className="font-bold text-amber-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-700" />
                    <span>Safety Mandates & Physical Preparation</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-amber-950 text-[11px]">
                    {inspectingPackage.safetyMandates.map((sm, i) => (
                      <li key={i}>{sm}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 bg-[#FAF9F6] border-t border-stone-200 flex items-center justify-between shrink-0">
              <span className="text-xs text-stone-500 hidden sm:inline">
                Quotation cost calculated transparently per pax size
              </span>

              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                <button
                  onClick={() => setInspectingPackage(null)}
                  className="px-4 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const id = inspectingPackage.id;
                    setInspectingPackage(null);
                    openInquireForPackage(id);
                  }}
                  className="px-6 py-2.5 rounded-xl bg-[#0F2922] hover:bg-[#153A30] text-white font-bold text-xs shadow-md flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                  <span>Request Bespoke Quotation</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
