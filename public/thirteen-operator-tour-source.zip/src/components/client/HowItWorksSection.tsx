import React from 'react';
import { useTour } from '../../context/TourContext';
import { FileText, UserCheck, Calculator, CreditCard, Compass, Sparkles, ArrowRight } from 'lucide-react';

export const HowItWorksSection: React.FC = () => {
  const { openInquireForPackage } = useTour();

  const steps = [
    {
      num: '01',
      title: 'Submit Bespoke Inquiry',
      subtitle: 'Digital Lead Capture (Decision #012)',
      desc: 'Select your preferred Indonesian destinations, dates, party size, and service tier via our encrypted inquiry form.',
      icon: FileText
    },
    {
      num: '02',
      title: 'Specialist Consultation',
      subtitle: 'Hybrid CS & Route Audit (Decision #013)',
      desc: 'Our senior travel designer examines partner availability, road timing, and volcanic safety advisories to craft your route.',
      icon: UserCheck
    },
    {
      num: '03',
      title: 'Personalized Quotation',
      subtitle: 'Itemized Pricing (Decision #008)',
      desc: 'Receive a transparent proposal with guaranteed foreign exchange pricing (USD/EUR/AUD) and a detailed daily schedule.',
      icon: Calculator
    },
    {
      num: '04',
      title: 'Secure Deposit & Voucher',
      subtitle: 'Escrow Bank Wire (Decision #018)',
      desc: 'Lock your dates with a 30% initial deposit. Receive instant digital voucher confirmation and 24/7 concierge contact.',
      icon: CreditCard
    },
    {
      num: '05',
      title: 'Seamless Expedition',
      subtitle: 'Verified Local Mastery (Decision #022)',
      desc: 'Meet your dedicated chauffeur and certified mountain guides. Travel with peace of mind from airport to volcano caldera.',
      icon: Compass
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-white text-slate-800 px-4 sm:px-6 lg:px-8 border-b border-stone-200">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
            <span>Section 5: Alur Penjualan & Pemesanan</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-['Playfair_Display'] text-slate-900">
            The Bespoke Booking Journey
          </h2>

          <p className="text-stone-600 text-sm leading-relaxed">
            Unlike mass-market booking platforms with hidden surcharges, THIRTEEN follows a disciplined five-stage verification pipeline before any travel commitment is finalized.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
          {steps.map((st) => {
            const Icon = st.icon;
            return (
              <div
                key={st.num}
                className="p-5 rounded-2xl bg-[#FAF9F6] border border-stone-200 flex flex-col justify-between hover:shadow-md hover:border-emerald-700/40 transition-all relative group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-2xl font-extrabold text-stone-300 group-hover:text-emerald-800 transition-colors">
                      {st.num}
                    </span>
                    <div className="w-8 h-8 rounded-lg bg-white border border-stone-200 flex items-center justify-center text-emerald-800 shadow-xs">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 text-sm font-['Playfair_Display']">
                      {st.title}
                    </h4>
                    <p className="text-[10px] text-emerald-800 font-mono mt-0.5">
                      {st.subtitle}
                    </p>
                  </div>

                  <p className="text-xs text-stone-600 leading-relaxed">
                    {st.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA Banner */}
        <div className="rounded-3xl bg-[#0F2922] text-white p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl sm:text-2xl font-bold font-['Playfair_Display'] text-white">
              Ready to Design Your Indonesian Expedition?
            </h3>
            <p className="text-xs sm:text-sm text-emerald-100/80 max-w-xl">
              Tell us your desired travel window and destinations. Our senior travel designer will respond with your personalized quotation.
            </p>
          </div>

          <button
            onClick={() => openInquireForPackage()}
            className="px-8 py-3.5 rounded-xl bg-white text-emerald-950 hover:bg-emerald-50 font-bold text-xs shadow-lg transition-all shrink-0 flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-emerald-800" />
            <span>Begin Your Inquiry</span>
          </button>
        </div>
      </div>
    </section>
  );
};
