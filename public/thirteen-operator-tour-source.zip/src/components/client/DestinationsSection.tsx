import React, { useState } from 'react';
import { useTour } from '../../context/TourContext';
import { Destination } from '../../types/tour';
import { ShieldAlert, Check, ArrowRight, X, Sparkles, Compass } from 'lucide-react';

export const DestinationsSection: React.FC = () => {
  const { destinations, openInquireForPackage } = useTour();
  const [selectedDestForModal, setSelectedDestForModal] = useState<Destination | null>(null);

  return (
    <section id="destinations" className="py-24 bg-[#FAF9F6] text-slate-800 px-4 sm:px-6 lg:px-8 border-b border-stone-200">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-widest flex items-center gap-2">
              <Compass className="w-4 h-4" />
              <span>Destinations Portfolio</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-['Playfair_Display'] text-slate-900">
              Bali, Bromo, Ijen &amp; Yogyakarta
            </h2>
            <p className="text-stone-600 text-sm leading-relaxed">
              Four iconic regions where raw volcanic geology converges with living ancient heritage. Each destination operates strictly under our audited partner network.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span> Core Catalog
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-50 text-sky-800 border border-sky-200 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-600"></span> Development
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-100 text-stone-600 border border-stone-200 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-stone-400"></span> Expansion Roadmap
            </span>
          </div>
        </div>

        {/* Destination Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {destinations.map((dest) => (
            <div
              key={dest.id}
              className="group rounded-3xl bg-white border border-stone-200/90 overflow-hidden hover:shadow-xl hover:border-emerald-700/40 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Image Cover */}
                <div className="relative h-60 overflow-hidden">
                  <img
                    src={dest.coverImage}
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                  
                  {/* Status Badge */}
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-md ${
                      dest.status === 'core' 
                        ? 'bg-emerald-900/90 text-white' 
                        : dest.status === 'development'
                        ? 'bg-sky-900/90 text-white'
                        : 'bg-stone-900/90 text-stone-200'
                    }`}>
                      {dest.status === 'core' ? 'Core Destination' : dest.status === 'development' ? 'Catalog Development' : 'Expansion Phase 2'}
                    </span>
                  </div>

                  {dest.heroBadge && (
                    <div className="absolute top-4 right-4">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/90 text-slate-800 border border-stone-200 backdrop-blur-md">
                        {dest.heroBadge}
                      </span>
                    </div>
                  )}

                  <div className="absolute bottom-3 left-4 right-4">
                    <h3 className="text-2xl font-bold font-['Playfair_Display'] text-white">
                      {dest.name}
                    </h3>
                  </div>
                </div>

                {/* Details */}
                <div className="p-5 space-y-4">
                  <p className="text-xs text-emerald-800 font-medium italic">
                    "{dest.tagline}"
                  </p>
                  
                  <p className="text-xs text-stone-600 leading-relaxed line-clamp-3">
                    {dest.description}
                  </p>

                  {/* Highlights Bulleted */}
                  <div className="space-y-1.5 pt-2 border-t border-stone-100">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400">Curated Experiences</span>
                    {dest.highlights.slice(0, 2).map((h, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-stone-700">
                        <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{h}</span>
                      </div>
                    ))}
                  </div>

                  {/* Safety & Protocol note if applicable */}
                  {dest.status === 'core' && dest.id === 'dest-ijen' && (
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200/80 text-[11px] text-amber-900 flex items-start gap-2">
                      <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <span>Activity clearance requires daily volcanological sulfur checks (Phase 1 Decision Record).</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-5 pt-0 flex items-center justify-between gap-3 border-t border-stone-100 mt-2">
                <button
                  onClick={() => setSelectedDestForModal(dest)}
                  className="text-xs text-stone-600 hover:text-emerald-800 font-semibold flex items-center gap-1 transition-colors pt-3"
                >
                  <span>Explore Dossier</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => openInquireForPackage()}
                  className="mt-3 px-3.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-800 text-emerald-800 hover:text-white border border-emerald-200 text-xs font-bold transition-all"
                >
                  Plan Journey
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Destination Dossier Modal */}
      {selectedDestForModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-stone-200 rounded-3xl w-full max-w-2xl text-stone-800 shadow-2xl relative overflow-hidden my-auto">
            <button
              onClick={() => setSelectedDestForModal(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/80 hover:bg-white text-stone-700 shadow-md backdrop-blur-md"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Image */}
            <div className="h-64 sm:h-72 relative">
              <img
                src={selectedDestForModal.coverImage}
                alt={selectedDestForModal.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent" />
              <div className="absolute bottom-4 left-6 right-6">
                <span className="text-xs uppercase tracking-wider font-semibold text-emerald-300">
                  {selectedDestForModal.statusLabel}
                </span>
                <h3 className="text-3xl font-bold font-['Playfair_Display'] text-white">
                  {selectedDestForModal.name}
                </h3>
              </div>
            </div>

            <div className="p-6 space-y-5 max-h-[60vh] overflow-y-auto text-xs sm:text-sm">
              <p className="text-stone-700 leading-relaxed">
                {selectedDestForModal.description}
              </p>

              <div>
                <h4 className="font-bold text-slate-900 mb-2 uppercase text-xs tracking-wider">
                  Signature Curated Experiences
                </h4>
                <div className="space-y-2">
                  {selectedDestForModal.highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-2.5 p-2.5 rounded-xl bg-stone-50 border border-stone-200">
                      <Check className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <span className="text-stone-800">{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Climate and Safety */}
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-800">
                  <ShieldAlert className="w-4 h-4" />
                  <span>Terrain, Climate & Safety Protocols</span>
                </div>
                <p className="text-stone-700 leading-relaxed text-[11px]">
                  {selectedDestForModal.climateSafetyNotes}
                </p>
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  onClick={() => setSelectedDestForModal(null)}
                  className="px-4 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    setSelectedDestForModal(null);
                    openInquireForPackage();
                  }}
                  className="px-6 py-2.5 rounded-xl bg-[#0F2922] hover:bg-[#153A30] text-white font-bold text-xs shadow-md flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                  <span>Request Custom Quotation for {selectedDestForModal.name}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
