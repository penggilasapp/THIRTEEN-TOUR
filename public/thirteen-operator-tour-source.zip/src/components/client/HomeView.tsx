import React from 'react';
import { HeroSection } from './HeroSection';
import { useTour } from '../../context/TourContext';
import { EXPERIENCES_DATA } from '../../data/experienceData';
import { TRAVEL_ARTICLES_DATA } from '../../data/guideData';
import { FAQSection } from './FAQSection';
import { 
  ArrowRight, 
  MapPin, 
  Compass, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  Trees, 
  Landmark, 
  Flame, 
  HeartHandshake,
  BookOpen,
  Phone
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { destinations, packages, setClientPage, openInquireForPackage } = useTour();

  const featuredDestinations = destinations.slice(0, 3);
  const featuredExperiences = EXPERIENCES_DATA.slice(0, 3);
  const featuredPackages = packages.filter(p => p.active).slice(0, 2);
  const featuredArticles = TRAVEL_ARTICLES_DATA.slice(0, 2);

  return (
    <div className="space-y-0">
      {/* 1. Hero Section */}
      <HeroSection />

      {/* 2. Featured Destinations Teaser */}
      <section className="py-20 bg-white border-b border-stone-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-800">
                Curated Regions
              </span>
              <h2 className="text-3xl font-extrabold font-['Playfair_Display'] text-slate-900 mt-1">
                Featured Destinations
              </h2>
              <p className="text-stone-600 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                Explore sacred volcanoes, emerald highland cascades, and ancient royal sultanates across the Indonesian archipelago.
              </p>
            </div>

            <button
              onClick={() => setClientPage('destinations')}
              className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100/80 px-4 py-2.5 rounded-xl border border-emerald-200 transition-all cursor-pointer self-start sm:self-center"
            >
              <span>Explore All Destinations</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredDestinations.map((dest) => (
              <div
                key={dest.id}
                onClick={() => setClientPage('destinations')}
                className="group rounded-3xl bg-[#FAF9F6] border border-stone-200 overflow-hidden hover:shadow-lg transition-all cursor-pointer"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={dest.coverImage}
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-5 right-5 text-white">
                    <span className="text-[10px] uppercase font-bold text-emerald-300">
                      {dest.statusLabel}
                    </span>
                    <h3 className="text-xl font-bold font-['Playfair_Display']">
                      {dest.name}
                    </h3>
                  </div>
                </div>
                <div className="p-5 space-y-2">
                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {dest.description}
                  </p>
                  <div className="pt-2 text-xs font-bold text-emerald-800 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>View Destination Dossier</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Signature Experiences Teaser */}
      <section className="py-20 bg-[#FAF9F6] border-b border-stone-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-800">
                Nature, Culture &amp; Adventure
              </span>
              <h2 className="text-3xl font-extrabold font-['Playfair_Display'] text-slate-900 mt-1">
                Signature Experiences
              </h2>
              <p className="text-stone-600 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                Hand-picked private excursions led by certified alpine miner guides, cultural historians, and experienced 4x4 drivers.
              </p>
            </div>

            <button
              onClick={() => setClientPage('experiences')}
              className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-white hover:bg-stone-100 px-4 py-2.5 rounded-xl border border-stone-200 transition-all cursor-pointer self-start sm:self-center shadow-2xs"
            >
              <span>View All Experiences</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredExperiences.map((exp) => (
              <div
                key={exp.id}
                onClick={() => setClientPage('experiences')}
                className="group rounded-3xl bg-white border border-stone-200 overflow-hidden hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-44 overflow-hidden">
                    <img
                      src={exp.coverImage}
                      alt={exp.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />
                    <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#0F2922] text-white">
                      {exp.categoryLabel}
                    </span>
                    <span className="absolute bottom-3 left-4 text-xs font-semibold text-emerald-200 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-300" />
                      <span>{exp.destination}</span>
                    </span>
                  </div>
                  <div className="p-5 space-y-2">
                    <h3 className="text-base font-bold font-['Playfair_Display'] text-slate-900 group-hover:text-emerald-900 transition-colors line-clamp-1">
                      {exp.title}
                    </h3>
                    <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                      {exp.description}
                    </p>
                  </div>
                </div>
                <div className="p-5 pt-0 flex items-center justify-between text-xs text-stone-500 border-t border-stone-100 mt-2">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{exp.duration}</span>
                  </span>
                  <span className="font-bold text-emerald-800 flex items-center gap-1">
                    <span>Explore</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Curated Tours Teaser */}
      <section className="py-20 bg-white border-b border-stone-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-800">
                Private Overland Routes
              </span>
              <h2 className="text-3xl font-extrabold font-['Playfair_Display'] text-slate-900 mt-1">
                Curated Expeditions &amp; Tours
              </h2>
              <p className="text-stone-600 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                Operating strictly as private tours with transparent pricing in USD or IDR, custom pacing, and luxury vehicle transfers.
              </p>
            </div>

            <button
              onClick={() => setClientPage('tours')}
              className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100/80 px-4 py-2.5 rounded-xl border border-emerald-200 transition-all cursor-pointer self-start sm:self-center"
            >
              <span>Browse Full Tour Catalog</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {featuredPackages.map((pkg) => (
              <div
                key={pkg.id}
                onClick={() => setClientPage('tours')}
                className="group rounded-3xl bg-[#FAF9F6] border border-stone-200 overflow-hidden hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={pkg.coverImage}
                    alt={pkg.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0F2922] text-white">
                      {pkg.indicativeDuration}
                    </span>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/90 text-slate-800">
                      {pkg.tourType.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-5 right-5 text-white">
                    <span className="text-xs text-emerald-300 font-medium">{pkg.destinationName}</span>
                    <h3 className="text-xl font-bold font-['Playfair_Display'] mt-0.5">{pkg.title}</h3>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {pkg.shortDescription}
                  </p>
                  <div className="flex items-center justify-between pt-2 border-t border-stone-200">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-stone-400 block">Indicative Rate</span>
                      <span className="font-mono text-lg font-bold text-emerald-950">
                        ${pkg.indicativePriceUsd?.toLocaleString()} USD
                        <span className="text-xs font-normal text-stone-500 font-sans ml-1">/ guest</span>
                      </span>
                    </div>
                    <span className="text-xs font-bold text-emerald-800 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      <span>View Program Details</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Trust Pillars & Governance Teaser */}
      <section className="py-20 bg-[#FAF9F6] border-b border-stone-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-5">
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-800">
                Phase 1 Operational Model
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold font-['Playfair_Display'] text-slate-900 leading-tight">
                Private-Only Expeditions Crafted With Zero Mass Tourism
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                THIRTEEN Operator Tour guarantees strictly private expeditions. Your private luxury vehicle, experienced alpine guides, and custom daily cadence are dedicated exclusively to your group.
              </p>
              <div className="space-y-2.5 pt-2">
                <div className="flex items-start gap-2.5 text-xs text-stone-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <span><strong>Zero Public Fixed Pricing:</strong> Transparent quotation locked upon your bespoke party size.</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-stone-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <span><strong>30% Commitment Deposit:</strong> Secure reservations with balance payable 14 days prior to tour.</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-stone-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <span><strong>Dual-Cartridge Gas Respirators:</strong> High-safety alpine gear for Mount Ijen sulfur craters.</span>
                </div>
              </div>
              <div className="pt-3">
                <button
                  onClick={() => setClientPage('about-us')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0F2922] text-white text-xs font-bold hover:bg-[#153A30] transition-colors cursor-pointer"
                >
                  <span>Read About Us &amp; Standards</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-6 rounded-3xl bg-white border border-stone-200 space-y-2">
                <ShieldCheck className="w-8 h-8 text-emerald-700" />
                <h4 className="text-sm font-bold text-slate-900">Audited Partners</h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Every 4x4 driver and mountain guide holds government licenses and verified first aid credentials.
                </p>
              </div>
              <div className="p-6 rounded-3xl bg-white border border-stone-200 space-y-2">
                <HeartHandshake className="w-8 h-8 text-emerald-700" />
                <h4 className="text-sm font-bold text-slate-900">24/7 Concierge</h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Designated Duty Manager and Travel Designer support before, during, and after your expedition.
                </p>
              </div>
              <div className="p-6 rounded-3xl bg-white border border-stone-200 space-y-2">
                <Sparkles className="w-8 h-8 text-emerald-700" />
                <h4 className="text-sm font-bold text-slate-900">3 Service Tiers</h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Tailored comfort levels: Essential Private, Private Signature, and Premium Concierge luxury.
                </p>
              </div>
              <div className="p-6 rounded-3xl bg-white border border-stone-200 space-y-2">
                <BookOpen className="w-8 h-8 text-emerald-700" />
                <h4 className="text-sm font-bold text-slate-900">Field Intelligence</h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Verified destination guides, sunrise photography calendars, and safety checklists.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Travel Guide Teaser */}
      <section className="py-20 bg-white border-b border-stone-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-800">
                Expedition Intelligence
              </span>
              <h2 className="text-3xl font-extrabold font-['Playfair_Display'] text-slate-900 mt-1">
                Travel Guides &amp; Field Advice
              </h2>
              <p className="text-stone-600 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                Practical insights to prepare for volcanic terrains, sacred temple sanctums, and executive rail journeys.
              </p>
            </div>

            <button
              onClick={() => setClientPage('travel-guide')}
              className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100/80 px-4 py-2.5 rounded-xl border border-emerald-200 transition-all cursor-pointer self-start sm:self-center"
            >
              <span>Explore All Travel Guides</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredArticles.map((article) => (
              <div
                key={article.id}
                onClick={() => setClientPage('travel-guide')}
                className="group rounded-3xl bg-[#FAF9F6] border border-stone-200 overflow-hidden hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={article.coverImage}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#0F2922] text-white">
                    {article.destinationTag}
                  </span>
                  <span className="absolute bottom-3 left-4 text-xs text-emerald-200">
                    {article.readingTime} • {article.publishDate}
                  </span>
                </div>
                <div className="p-6 space-y-2">
                  <h3 className="text-lg font-bold font-['Playfair_Display'] text-slate-900 group-hover:text-emerald-900 transition-colors line-clamp-1">
                    {article.title}
                  </h3>
                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {article.summary}
                  </p>
                  <div className="pt-2 text-xs font-bold text-emerald-800 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Read Full Guide</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions: Booking & Travel Requirements */}
      <FAQSection />

      {/* Bottom Contact Callout */}
      <section className="py-20 bg-[#0F2922] text-white px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/10 text-emerald-200 text-xs font-semibold border border-white/20">
            <Phone className="w-3.5 h-3.5 text-emerald-300" />
            <span>24/7 Dedicated Concierge</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-['Playfair_Display'] text-white">
            Ready to Design Your Bespoke Indonesian Expedition?
          </h2>

          <p className="text-xs sm:text-sm text-emerald-100/80 max-w-xl mx-auto leading-relaxed">
            Connect with our certified Travel Designers to create a tailored private itinerary, request transparent pricing, or clarify mountain safety requirements.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => openInquireForPackage()}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white text-emerald-950 hover:bg-emerald-50 text-xs font-bold transition-all shadow-md cursor-pointer"
            >
              Request Bespoke Quotation
            </button>
            <button
              onClick={() => setClientPage('contact')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold border border-white/20 transition-all cursor-pointer"
            >
              Contact Concierge Desk
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
